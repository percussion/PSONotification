java -cp lib/rxclient.jar:lib/saxon.jar:lib/rxserver.jar:lib/xmlParserAPIs.jar:lib/xercesImpl.jar:lib/log4j.jar com.percussion.util.PSExtensionInstallTool . .









